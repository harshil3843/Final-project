# Exam-Seating-Arrangement-Project
To simplify examination hall allotment and seating arrangement for the student, an web application for automatic seating arrangement is developed. 
